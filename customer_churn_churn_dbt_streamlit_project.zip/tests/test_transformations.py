import os
import pandas as pd
from src.transformations import transform_churn_data

def test_transformations(tmp_path):
    raw_path = tmp_path / "raw.csv"
    df = pd.DataFrame({
        "CustomerID": [1, 2, 3],
        "Tenure": [1, 10, 5],
        "Monthly Charges": [10.0, 20.0, 30.0],
        "Churn": ["Yes", "No", "Yes"]
    })
    df.to_csv(raw_path, index=False)

    processed_dir = tmp_path / "processed"
    out_path = transform_churn_data(str(raw_path), str(processed_dir))
    assert os.path.exists(out_path)
    df_processed = pd.read_csv(out_path)
    assert "expected_lifetime_value" in df_processed.columns
    assert "churn_flag" in df_processed.columns
