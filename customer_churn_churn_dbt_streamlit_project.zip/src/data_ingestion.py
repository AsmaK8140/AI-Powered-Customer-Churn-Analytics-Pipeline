import os
import shutil
from datetime import datetime

def ingest_csv(input_csv: str, raw_dir: str) -> str:
    os.makedirs(raw_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"churn_raw_{timestamp}.csv"
    dest_path = os.path.join(raw_dir, filename)
    shutil.copy2(input_csv, dest_path)
    return dest_path
