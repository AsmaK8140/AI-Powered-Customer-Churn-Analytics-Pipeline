from sqlalchemy import create_engine
import pandas as pd

def init_db(db_url: str):
    engine = create_engine(db_url)
    return engine

def load_to_db(engine, csv_path: str, table_name: str):
    df = pd.read_csv(csv_path)
    df.to_sql(table_name, con=engine, if_exists="replace", index=False)
