import os
import pandas as pd
from datetime import datetime

def transform_churn_data(raw_path: str, processed_dir: str) -> str:
    os.makedirs(processed_dir, exist_ok=True)
    df = pd.read_csv(raw_path)

    # Basic cleaning: drop duplicates, standardize column names
    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]
    df = df.drop_duplicates()

    # Example engineered features
    if "tenure" in df.columns and "monthly_charges" in df.columns:
        df["expected_lifetime_value"] = df["tenure"] * df["monthly_charges"]

    if "churn" in df.columns:
        df["churn_flag"] = df["churn"].astype(str).str.strip().str.upper().isin(["YES", "Y", "TRUE", "1"]).astype(int)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    processed_path = os.path.join(processed_dir, f"churn_processed_{timestamp}.csv")
    df.to_csv(processed_path, index=False)
    return processed_path
