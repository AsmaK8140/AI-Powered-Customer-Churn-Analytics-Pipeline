import streamlit as st
import pandas as pd
from src.config_loader import load_config
from src.data_ingestion import ingest_csv
from src.transformations import transform_churn_data
from src.db_utils import init_db, load_to_db
import os

st.set_page_config(page_title="Customer Churn Analytics", layout="wide")

config = load_config()
raw_dir = config["paths"]["raw_dir"]
processed_dir = config["paths"]["processed_dir"]
outputs_dir = config["paths"]["outputs_dir"]
db_url = config["database"]["url"]

os.makedirs(raw_dir, exist_ok=True)
os.makedirs(processed_dir, exist_ok=True)
os.makedirs(outputs_dir, exist_ok=True)

st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Upload & Run Pipeline", "View Processed Data"])

if page == "Upload & Run Pipeline":
    st.title("Customer Churn Analytics Pipeline")
    st.write("Upload a churn CSV file to run the pipeline end-to-end.")

    uploaded_file = st.file_uploader("Upload CSV", type=["csv"])
    if uploaded_file is not None:
        temp_path = os.path.join(raw_dir, "uploaded_temp.csv")
        with open(temp_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        if st.button("Run Pipeline"):
            with st.spinner("Running pipeline..."):
                raw_path = ingest_csv(temp_path, raw_dir)
                processed_path = transform_churn_data(raw_path, processed_dir)
                engine = init_db(db_url)
                load_to_db(engine, processed_path, table_name="churn_customers")

                st.success("Pipeline completed successfully!")
                st.write("Processed file:", processed_path)

                df = pd.read_csv(processed_path)
                st.dataframe(df.head())

                out_path = os.path.join(outputs_dir, "churn_processed_latest.csv")
                df.to_csv(out_path, index=False)
                with open(out_path, "rb") as f:
                    st.download_button(
                        "Download Processed CSV",
                        data=f,
                        file_name="churn_processed.csv",
                        mime="text/csv"
                    )

elif page == "View Processed Data":
    st.title("View Processed Churn Data")
    latest_file = None
    if os.path.exists(outputs_dir):
        files = [
            os.path.join(outputs_dir, f)
            for f in os.listdir(outputs_dir)
            if f.endswith(".csv")
        ]
        if files:
            latest_file = max(files, key=os.path.getmtime)

    if latest_file:
        st.write("Showing latest processed file:", latest_file)
        df = pd.read_csv(latest_file)
        st.dataframe(df.head(100))
    else:
        st.info("No processed data found. Please run the pipeline first.")
